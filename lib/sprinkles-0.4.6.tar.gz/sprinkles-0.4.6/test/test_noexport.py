import sprinkles

class TestSprinkle(sprinkles.Sprinkle):
    party = "fun"

class SecondTestSprinkle(sprinkles.Sprinkle):
    party = "time"
